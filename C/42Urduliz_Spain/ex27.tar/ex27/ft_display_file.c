/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_display_file.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vsobolev <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/09/24 17:20:09 by vsobolev          #+#    #+#             */
/*   Updated: 2026/09/24 17:20:18 by vsobolev         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* TASK
• Create a program called ft_display_file that displays, on the standard output,
only the content of the file given as argument.
• The submission directory should have a Makefile with the following rules : all,
clean, fclean. The binary will be called ft_display_file.
• The malloc function is forbidden. You can only do this exercise by declaring a
fixed-sized array.
• All files given as arguments will be valid.
• Error messages have to be displayed on their reserved output followed by a new
line.
• If no argument is given, it should display
"File name missing."
• If there is more than one argument, it should display
"Too many arguments."
• If the file cannot be read, it should display
"Cannot read file."
*/

#include <fcntl.h>
#include <unistd.h>

void	ft_putstr(char *str, int fd)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		write(fd, &str[i], 1);
		i++;
	}
}

int	main(int argc, char *argv[])
{
	char	*file;
	char	buf[1024];
	int		fd;
	int		bytes_read;

	if (argc < 2)
		ft_putstr("File name missing.\n", 2);
	if (argc > 2)
		ft_putstr("Too many arguments.\n", 2);
	if (argc != 2)
		return (-1);
	file = argv[1];
	fd = open(file, O_RDONLY);
	if (fd == -1)
	{
		ft_putstr("Cannot read file.\n", 2);
		return (1);
	}
	bytes_read = read(fd, buf, 1024);
	while (bytes_read > 0)
	{
		write(1, buf, bytes_read);
		bytes_read = read(fd, buf, 1024);
	}
	close(fd);
}
